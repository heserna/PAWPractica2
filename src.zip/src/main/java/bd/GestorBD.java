/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;


import java.sql.*;
import java.util.*;

/**
 *
 * @author heserna
 */
public class GestorBD {

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<String> getArticulosLike(String nombre) throws SQLException {
        List<String> articulos = new ArrayList<String>();
        Connection con = null;

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electrosa?serverTimezone=GMT%2B2", "root", "root");
        String consulta = "select * from ARTICULO where nombre LIKE CONCAT( '%',?,'%') ";

        PreparedStatement pst = con.prepareStatement(consulta);
        pst.setString(1, nombre);
        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            articulos.add(rs.getString("nombre"));
            System.out.println(rs.getString("nombre"));
        }
        pst.close();
        con.close();
        return articulos;

    }

    public GestorBD() {
    }
}
