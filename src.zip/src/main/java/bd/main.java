/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.sql.SQLException;
import java.util.*;

/**
 *
 * @author heserna
 */
public class main {
    public static void main(String[] args) {
        GestorBD gbd = new GestorBD();
        try{
        List<String> arts = gbd.getArticulosLike("sci");
         System.out.println("Hola");
        for ( int i = 0 ; i<arts.size();i++){
           
            System.out.println(arts.get(i));
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
